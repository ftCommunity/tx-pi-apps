<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>TSCalApp</name>
    <message>
        <location filename="tscal.py" line="91"/>
        <source>Reboot</source>
        <translation>Reboot</translation>
    </message>
    <message>
        <location filename="tscal.py" line="104"/>
        <source>It&apos;s recommended to restart the device.</source>
        <translation>Es wird ein Neustart des Gerätes empfohlen.</translation>
    </message>
    <message>
        <location filename="tscal.py" line="104"/>
        <source>Do you want to reboot now?</source>
        <translation>Möchtest Du jetzt den Reboot durchführen?</translation>
    </message>
</context>
</TS>
