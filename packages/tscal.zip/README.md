# TS-Cal - An application to calibrate touchscreens for the TX-Pi

Simple application which is used to calibrate the TX-Pi touchscreen.

## Note:
The master branch must be stable since it used by the TX-Pi setup
script.
