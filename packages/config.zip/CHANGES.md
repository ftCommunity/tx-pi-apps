# Changes

# 1.0.0 - 2020-04-22
* Moved scripts to /opt/ftc/apps/system/txpiconfig

# 0.0.7 - 2019-05-03
* Calibration works for 3,5" rotate=90
* Added support to enable / disable I²C bus
* Initial release to be used by the master branch of the TX-Pi setup

# 0.0.6 - 2019-04-29
* Better support for display config (calibration is updated, does
  not work for rotate=90 yet)

# 0.0.5 - 2019-04-28
* Added display config
* Support more than one arg in Pane.run_script

# 0.0.4 - 2019-04-27
* Removed "About" menu, adds no value but takes away valuable space
* Added translation to German
* Some internal code changes

# 0.0.3 - 2019-04-27
* Another hostname config fix

# 0.0.2 - 2019-04-27
* Fixed hostname pane

# 0.0.1 - 2019-04-26
* Initial release
